# My Own Collection

## Модуль my_own_module
Создаёт файл на удалённом хосте.

## Роль my_own_role
Использует модуль для создания файла.
